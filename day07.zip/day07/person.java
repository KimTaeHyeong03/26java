package day07;

public class person {
	public static String name;
	public int age;
	public char abc;
	
	
	private String addr;
	
	//기본 생성자 정의 : 클래스 이름과 동일한 메소드, 객체 생성 시 호출(근데 이 과정은 컴파일러가 해줘서 굳이 할 필요 없음)
	//역할 ㅣ 필드(변수 초기화)
	public person() {
		name = "홍길동";
		age = 20;
		abc = 'A';
		System.out.println("객체가 생성됨.");
	}
	
	public static String getname() {
		return name;
	}
	
	
	public void food() {
		System.out.println("밥먹기");
	}
	public void 운동하기(String s) {
		System.out.println(s + "종목을 운동합니다.");
	}

}
