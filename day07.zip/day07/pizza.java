package day07;

class circle {
	int num;
	String name;
	
	public circle() {
		this(0,"");
	}
	
	public circle(int num) {
		this(num, "불고기피자");
	}
	
	public circle(int num, String name) {
		this.num = num;
		this.name = name;
	}
	
	public double area() {
		return 3.14 * num * num;
	}
	

}


public class pizza {

	public static void main(String[] args) {
		circle zero = new circle();
		circle donut = new circle();
		circle pizza = new circle(10, "치즈피자");
		
		
//		zero.num = 10;
//		zero.name = "원형";
		
//		donut.num = 5;
//		donut.name = "자바도넛";
		
		System.out.println(zero.name + "의 면적은 " + zero.area());
		System.out.println(donut.name + "의 면적은 " + donut.area());
		System.out.println(pizza.name + "의 면적은 " + pizza.area());
	

	}

}
