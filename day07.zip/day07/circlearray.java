package day07;

import java.util.Scanner;



public class circlearray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		circle c[];
//		c = new circle[5];
//		
//		for(int i = 0; i < c.length; i++) {
//			c[i] = new circle(i);
//		}
//		
//		for(int i = 0; i < c.length; i++) {
//			System.out.print((int)c[i].area()+" ");
//		}
//		
		Scanner scanner = new Scanner(System.in);
		
		book2 b[];
		b = new book2[2];
		
		for(int i = 0; i < b.length; i++) {
			System.out.print("제목 : ");
			String title = scanner.nextLine();
			System.out.print("저자 : ");
			String name = scanner.nextLine();
			
			b[i] = new book2(title, name);
		}
		for(int i = 0; i < b.length; i++) {
			System.out.println(b[i].title + " " + b[i].name);
		}
		
	}
}
