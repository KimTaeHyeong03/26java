package day07;

class book2 {
	String title;
	String name;
	
	
	public book2(String a) {
		title = a; name = "작자미상";
	}
	
	public book2(String a, String b) {
		title = a; name = b;
	}
}

public class book {
	public static void main(String[] args) {
		book2 titlePrince = new book2("어린왕자", "생텍쥐페리");
		book2 titlestory = new book2("춘향전");
		System.out.println(titlePrince.title + "의 저자는 " + titlePrince.name + "입니다.");
		System.out.println(titlestory.title + "의 저자는 " + titlestory.name + "입니다.");
		

	}
}
