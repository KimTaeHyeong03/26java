package day07;

public class persontest {
	public static void main(String[] args) {
		person hong = new person();
		person kim = new person();
//		hong.name = "홍길동";
//		hong.age = 20;
//		hong.abc = 'A';
		hong.food();
		hong.운동하기("헬스");
		
//		hong.name = "김길동";
//		hong.age = 21;
//		hong.abc = 'B';
		hong.food();
		hong.운동하기("달리기");
		
		System.out.println(person.getname()); //static 메소드 호출은 클래스 이름.으로 사용가능
	}
}
