package day05;

public class Array05 {

	public static void main(String[] args) {
		double score[][] = {{3.3, 3.4},
							{3.5, 3.6},
							{3.7, 4.0},
							{4.1, 4.2}};
		
		double sum = 0;
		
		try {
			for(int i = 0; i < 5; i++) {
				for(int j = 0; j < score[i].length; j++) {
					sum += score[i][j];
				}
			}
		} catch(ArrayIndexOutOfBoundsException ao) {
			ao.printStackTrace();
		}
		
		System.out.println("모든 학년의 평균은 " + sum/(score.length*score[0].length) + "입니다.");
	}

}
