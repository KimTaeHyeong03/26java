package day05;

import java.util.Scanner;


public class array02 {

	public static void main(String[] args) {
		int sum = 0;
		int avg = 0;
		
		Scanner scanner = new Scanner(System.in);
		
		int array[] = new int[5];
		
		for(int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
			sum += array[i];
		}
		
		avg = sum / array.length;
		
		System.out.println("평균은 " + avg + "입니다.");
		scanner.close();
	}

}
