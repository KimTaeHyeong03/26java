package day05;
import java.util.Scanner;

public class Array01 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int intarray[] = new int[5];
		
		int max = 0;
		int avg = 0;
		System.out.print("양수 5개를 입력하십시오 : ");
		for(int i = 0; i < intarray.length; i++) {
			intarray[i] = scanner.nextInt();
			avg += intarray[i];
			if(intarray[i] > max) {
				max = intarray[i];
			}
		}
		avg = avg / intarray.length;
		System.out.println("가장 큰 값은" + max + "입니다.");
		System.out.print("수의 평균은 " + avg + "입니다.");
		
		scanner.close();
	}
}
