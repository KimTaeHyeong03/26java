package day09;

public class human extends animal {
	private String addr;
	
	public human() {
		
	}
	
	public human(String name, int age) {
		super(name, age);
	}
	
	
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	public String getAddr(){
		return addr;
	}
}
