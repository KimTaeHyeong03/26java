package day09;

public class Student extends human {
	private String sid;
	
	public Student() {
		
	}
	
	public Student(String name, int age, String sid) {
		super(name, age);
		this.sid = sid;
	}
	
	
	public void setSid(String sid) {
		this.sid = sid;
	}
	
	public String getSid() {
		return sid;
	}
	
}
