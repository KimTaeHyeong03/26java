package day09;

public class animaltest {

	public static void main(String[] args) {
		animal cat = new animal();
		human hong = new human();
		
		
		//cat.name = "뽀삐";
		cat.setName("뽀삐");
		hong.setName("홍길동");
		//cat.age = 10;
		cat.setAge(10);
		hong.setAge(20);
		
		hong.setAddr("대전동구 용운동");

		System.out.println(cat.getName() +"의 나이는 " + cat.getAge());
		System.out.println(hong.getName() + "의 나이는 " + hong.getAge() + " 주소는 " + hong.getAddr());
		
	}

}
