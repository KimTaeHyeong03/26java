package day10;

public class student extends person{

	public student(String name, String id) {
		super(name, id);
	}
	
}
