package day10;

public class rect extends shape{
	public void draw() {
		System.out.println("랙트를 그리다.");
	}
}
