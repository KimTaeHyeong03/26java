package day10;

public class schoolapp {

	public static void print(person p) {
//		if(p instanceof person) {
//			System.out.println("사람객체 입니다.");
//		}
		if(p instanceof student) {
			System.out.println("학생객체 입니다.");
		}
		if(p instanceof researcher) {
			System.out.println("리서처객체 입니다.");
		}
	}
	
	
	public static void main(String[] args) {
		person p = new person("이사람", "0110");
		student p1 = new student("저사람", "1111");
		researcher p2 = new researcher("그사람", "1001");
		
		print(p1);
		
	}

}
