package day10;

public class circle extends shape{
	public void draw() {
		System.out.println("원을 그리다.");
	}
}
