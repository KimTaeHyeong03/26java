package day10;

public class tri extends shape{
	@Override
	public void draw() {
		System.out.println("삼각형 도형을 그리다.");
		
	}
}
