package day10;

public class researcher extends person{

	public researcher(String name, String id) {
		super(name, id);
	}
}
