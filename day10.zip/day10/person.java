package day10;

public class person {
	String name;
	String id;
	
	public person(String name, String id) {
		this.name = name;
		this.id = id;
	}
	
	public void printInfo() {
		System.out.println("이름: " + name + " 아이디: " + id);
	}
	
}
