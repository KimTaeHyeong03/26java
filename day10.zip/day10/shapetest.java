package day10;

import java.util.ArrayList;

public class shapetest {

	public static void main(String[] args) {
		
		shape s = new line();
		shape c = new circle();
		
		ArrayList<shape> array = new ArrayList<shape>();
		array.add(s);
		array.add(c);
		array.add(new line());
		array.add(new tri());
		
		for(shape sp:array) {
			if(sp instanceof line) {
				System.out.println("선객체");
			}
			if(sp instanceof circle) {
				System.out.println("원객체");
			}
			if(sp instanceof tri) {
				System.out.println("삼각객체");
			}
		}
	}
}
