package day10;

public class line extends shape{
	public void draw() {
		System.out.println("선을 그리다.");
	}
}
