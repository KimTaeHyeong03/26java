package day14;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class MyJFrame extends JFrame {
	public void InnerClassListener() {
		setTitle("나만의 액션 타이틀");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container con = getContentPane();
		setLayout(new FlowLayout());
		JButton btn = new JButton("소개");
		con.add(btn);
		JTextField jf;
		con.add(jf = new JTextField(20));
		JButton btn2 = new JButton("확인");
	}
		
	public void actionPerformed(ActionEvent e) {
		
		if(obj == btn) System.out.println("소개 버튼 클릭");
	}
		
	btn2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		System.out.println(jf.getText());
		}
	});
		
	setSize(350, 150);
	setVisible(true);
}


public static void main(String[] args) {
	
}
