package day14;

import java.awt.event.MouseEvent;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.*;
import java.awt.event.MouseListener;
import javax.swing.*;



public class MouseListenerEx2 extends JFrame {
	
	JLabel lb;
	
	public MouseListenerEx2() {
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		lb = new JLabel("안녕하세요");
		lb.setLocation(30, 30);
		lb.setSize(50, 20);
		con.add(lb);
		
		con.addMouseMotionListener(new MyMouseListener2());
		
		
		setSize(400, 400);
		setVisible(true);
		setTitle(lb.getText());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}
	
	public static void main(String[] args) {
		new MouseListenerEx2();
		
		
		
		
	}
	
	class MyMouseListener2 extends MouseMotionAdapter {

		@Override
		public void mouseDragged(MouseEvent e) {
			lb.setText("MouseDragged ("+e.getX()+", "+e.getY()+")");
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			lb.setText("MouseMoved ("+e.getX()+", "+e.getY()+")");
		}
		
	}
	
}
