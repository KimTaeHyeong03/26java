package day14;

import java.awt.event.MouseEvent;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.awt.event.MouseListener;
import javax.swing.*;



public class MouseListenerEx extends JFrame {
	
	JLabel lb;
	
	public MouseListenerEx() {
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		lb = new JLabel("안녕하세요");
		lb.setLocation(30, 30);
		lb.setSize(50, 20);
		con.add(lb);
		
		con.addMouseListener(new MyMouseListener());
		
		
		setSize(400, 400);
		setVisible(true);
		setTitle(lb.getText());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}
	
	public static void main(String[] args) {
		new MouseListenerEx();
		
		
		
		
	}
	
	class MyMouseListener extends MouseAdapter {

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			
			int x = e.getX();
			int y = e.getY();
			lb.setLocation(x, y);
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	
}
