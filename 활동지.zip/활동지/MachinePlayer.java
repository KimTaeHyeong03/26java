package day10;

import java.util.Random;

public class MachinePlayer extends Player{
	public MachinePlayer(String name) {
		super(name);
	}
	
	public String turn() {
		Random random = new Random();
		int num = random.nextInt(3);
		return shape[num];
	}
}
