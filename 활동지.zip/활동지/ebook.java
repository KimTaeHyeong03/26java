package day10;

class book {
	private String title;
	
	protected book(String title) {
		this.title = title;
	}
	
	protected String getbook() {
		return title;
	}
}

public class ebook extends book{
	int inch;
	int page;
	
	public ebook(String title, int inch) {
		super(title);
		this.inch = inch;
	}
	
	public void printInfo() {
		System.out.println(super.getbook() + "은 " + inch + "인치 전자책입니다.");
	}
	
	public void text2speech(int page) {
		this.page = page;
		System.out.println(page + "페이지의 텍스트를 음성으로 출력합니다.");
	}
	
	
	

	public static void main(String[] args) {
		ebook javabook = new ebook("자바에센셜-전자책", 14);
		javabook.printInfo();
		javabook.text2speech(3);
		

	}

}
