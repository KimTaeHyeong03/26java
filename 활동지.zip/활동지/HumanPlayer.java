package day10;

import java.util.Scanner;

public class HumanPlayer extends Player{
	
	
	public HumanPlayer(String name) {
		super(name);
	}
	
	public String turn() {
		String RSP;
		
		System.out.print(name + "님, 뭘 내시겠습니까? ");
		
		Scanner scanner = new Scanner(System.in);
		
		RSP = scanner.next();
	
		return RSP;
	}
}
