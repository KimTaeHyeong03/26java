package my.app;
import java.util.HashMap;

public class HashmapEx {

	public static void main(String[] args) {
		HashMap<String,Integer> hashm = new HashMap<String,Integer>();
		hashm.put("김은비", 97);
		hashm.put("하여린", 88);
		hashm.put("전아린", 98);
		hashm.put("이동건", 70);
		hashm.put("양승연", 99);
		
		

	}

}
