package my.app;
import java.util.ArrayList;
import java.util.Scanner;


public class name {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		ArrayList<String> alist = new ArrayList<String>();
		for(int i = 0; i < 4; i++) {
			System.out.print("이름을 입력하세요: ");
			alist.add(scan.nextLine());
		}
		
		System.out.println(alist);
		
	}

}
