package day02;

public class Hello0310 {

	public static void main(String[] args) {
		System.out.println("자바를 이용해");
		System.out.print("간단한 홈페이지 혹은 게임을\n");
		System.out.print("만들어보고\n싶습니다.");
		
		

	}

}
