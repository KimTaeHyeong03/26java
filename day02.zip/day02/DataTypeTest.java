package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본형 변수 선언
		boolean istrue;
		int age;
		double height, weight;
		
		// 변수 초기화
		istrue = false;
		age = 23;
		height = 180.1;
		weight = 89.6;
		
		
		// 2. 레퍼런스형 3개(클래스, 배열, 인터페이스)
		String name; //클래스
		name = "김태형";
		String home = new String("서문 자취방");
		
		//레퍼런스형 만들 때 규칙(아래와 같은 형식을 가져야 함, string만 기존과 같은 형식으로 사용가능)
		String s = new String("홍길동");
		DataTypeTest dtt = new DataTypeTest();
		
		
		
		// 변수 값 출력하기
		System.out.println(istrue);
		System.out.println("나이: "+age);
		System.out.println("키: "+height);
		System.out.println("몸무게: "+weight);
		System.out.println("이름: "+name);
		System.out.println("주소: "+home);
		
		//System.out.println(dtt);
		
	}

}
