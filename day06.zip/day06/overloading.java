package day06;

public class overloading {

	
	public static void coffee(int a) {
		System.out.println("블랙 커피 만듭니다.");
	}
	
	public static void coffee(int a, int b) {
		System.out.println("크림 커피 만듭니다.");	
	}
	
	public static void coffee(int a, int b, int c) {
		System.out.println("믹스 커피 만듭니다.");
	}
	
	
	public static void main(String[] args) {
		coffee(3,3,3);

	}

}
