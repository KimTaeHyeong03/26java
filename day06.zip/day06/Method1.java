package day06;

import java.util.Scanner;

public class Method1 {

	

	public static void add() {
		Scanner scanner = new Scanner(System.in);
		
		int num[] = new int[2];
		int sum = 0;
		
		for(int i = 0; i < 2; i++) {
			num[i] = scanner.nextInt();
			
			sum += num[i];
		}
		
		System.out.println(sum);
		
	}
	
	
	public static void add(int a, int b) {
		System.out.println(a + b);
	}
	
	
	
	public static int add1() {
		Scanner scanner = new Scanner(System.in);
		int num[] = new int[2];
		int sum = 0;
		
		for(int i = 0; i < 2; i++) {
			num[i] = scanner.nextInt();
			
			sum += num[i];
		}
		return sum;
	}
	

	public static int add1(int a, int b) {
		return a + b;
	}
	
	
	
	public static void main(String[] args) {
		int method;
		//add();
		//add(50, 60);
		//method = add1();
		
		System.out.println(add1());
		System.out.println(add1(50, 60));
		
	}

}
