package day06;

import java.util.Scanner;

public class Method2 {

	public static int max() {
		Scanner scanner = new Scanner(System.in);
		
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		
		if(num1 > num2) {
			return num1;
		}
		else if(num1 < num2) {
			return num2;
		}
		else {
			return num1;
		}
		
	}
	
	/*
	 * public static int abcd() { Scanner scanner = new Scanner(System.in);
	 * 
	 * int num1 = scanner.nextInt(); int num2 = scanner.nextInt(); String a =
	 * scanner.next();
	 * 
	 * switch (a) { case "+": return add(num1, num2);
	 * 
	 * case "-": return sub(num1, num2);
	 * 
	 * case "*": return mul(num1, num2);
	 * 
	 * case "/": return div(num1, num2); }
	 * 
	 * }
	 */
	

	public static int add(int a, int b) {
		return a + b;
	}
	public static int sub(int a, int b) {
		return a - b;
	}
	public static int mul(int a, int b) {
		return a * b;
	}
	public static int div(int a, int b) {
		return a / b;
	}

	
	
	public static void main(String[] args) {
		//System.out.println(max());
		//int result = abcd();
		
		
		Scanner scanner = new Scanner(System.in);
		
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		String a = scanner.next();
		
		switch (a) {
		case "+":
			System.out.print(add(num1, num2));
			break;
		case "-":
			System.out.print(sub(num1, num2));
			break;
		case "*":
			System.out.print(mul(num1, num2));
			break;
		case "/":
			System.out.print(div(num1, num2));
			break;
		}
	}

}
