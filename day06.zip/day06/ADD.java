package day06;

import java.util.Scanner;

public class ADD {

	public static void main(String[] args) {
		
		double num[] = new double[2];
		double sum = 1;
		
		Scanner scanner = new Scanner(System.in);
		
		
		System.out.print("두 수를 입력하여 주십시오 : ");
		for(int i = 0; i < 2; i++) {
			num[i] = scanner.nextDouble();
			
			sum *= num[i];
		}
		
		System.out.println("두 수의 곱은 : " + sum + "입니다.");
		scanner.close();
		
	}
}
