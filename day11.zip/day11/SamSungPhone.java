package day11;

public class SamSungPhone implements phoneinterface {
	
	public static void main(String[] args) {
		SamSungPhone sp = new SamSungPhone();
		sp.sendCall();
		sp.receiveCall();
		
		phoneinterface ph = new SamSungPhone();
		
	}

	@Override
	public void sendCall() {
		System.out.println("띠리리리링");
		
	}

	@Override
	public void receiveCall() {
		System.out.println("전화가 왔습니다.");
		
	}

}
