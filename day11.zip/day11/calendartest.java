package day11;
import java.util.*;
public class calendartest {

	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		System.out.print("현재 날짜 : ");
		System.out.print(calendar.get(Calendar.YEAR) + "년 ");
		System.out.print(calendar.get(Calendar.MONTH) + 1 + "월 ");
		System.out.print(calendar.get(Calendar.DATE) + "일 ");
		
		System.out.print(calendar.get(Calendar.HOUR) + "시 ");
		System.out.print(calendar.get(Calendar.MINUTE) + "분 ");
		System.out.println(calendar.get(Calendar.SECOND) + "초 ");
		
		
		System.out.print(calendar.get(Calendar.HOUR_OF_DAY) + "시 ");
	}

}
