package day11;

public class SmartPhone extends Calc implements phoneinterface{
	
	
	
	
	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone();
		
		sp.sendCall();
		sp.receiveCall();
		System.out.println("3 + 5 = " + sp.calculate(3, 5));
		
		System.out.println(sp.toString());
	}

	@Override
	public void sendCall() {
		System.out.println("스마트폰 벨");
		
	}

	@Override
	public void receiveCall() {
		System.out.println("전화가 왔습니다.");
		
	}
	
	@Override
	public String toString() {
		return "스마트폰"; 
	}
}
