package day11;
class point{
	
	private int x, y;
	
	public point(int x, int y){
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	@Override
	public String toString() {
		return "Point("+ x +", "+ y +")";
	}
	
	
}

public class pointtest {

	public static void main(String[] args) {
		point point = new point(300, 500);
		
		System.out.println(point.toString());
		
	}
}
