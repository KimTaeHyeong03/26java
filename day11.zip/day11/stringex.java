package day11;

public class stringex {

	public static void main(String[] args) {
		String a = new String(" C#");
		String b = new String(",C++");
		
		System.out.println(a + "의 길이는 " + a.length());
		System.out.println(a.contains("#"));
		
		a = a.concat(b);
		System.out.println(a);
		
		a = a.trim();
		System.out.println(a);
		
		a = a.replace("#", "java");
		System.out.println(a);
		
		
		String s[] = a.split(",");
		
		for(int i = 0; i < s.length; i++) {
			System.out.println("분리된 문자열" + i + ": " + s[i]);
		}
		a = a.substring(5); // 인덱스5부터끝까지서브스트링리턴
		System.out.println(a);
		
		char c = a.charAt(2); // 인덱스2의문자리턴
		System.out.println(c);
	}

}
