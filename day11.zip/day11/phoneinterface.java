package day11;

interface phoneinterface {
	public static final int timeout = 10000;
	public abstract void sendCall();
	public abstract void receiveCall();
	public default void printLogo() {
		System.out.println("** phone **");
	}
}